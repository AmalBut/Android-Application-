package com.example.advancepizza;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
public class PizzaJasonParser {
    public static List<Pizza> getObjectFromJason(String jason) {
        List<Pizza> pizzas;
        try {
            JSONArray jsonArray = new JSONArray(jason);
            pizzas = new ArrayList<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = new JSONObject();
                jsonObject = (JSONObject) jsonArray.get(i);
                Pizza pizza = new Pizza();
                pizza.setType(jsonObject.getString("type"));
               // pizza.setPrice(jsonObject.getInt("price"));
                //pizza.setSize(jsonObject.getString("size"));
                pizzas.add(pizza);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return pizzas;
    }
}