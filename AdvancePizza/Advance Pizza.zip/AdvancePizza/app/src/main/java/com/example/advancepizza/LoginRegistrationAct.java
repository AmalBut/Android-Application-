package com.example.advancepizza;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;
import android.widget.ImageView;


public class LoginRegistrationAct extends AppCompatActivity {

    Intent intent;
    //pizza.setImageResource(R.drawable.pizza);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_registration);

        Button signin_button = findViewById(R.id.signin);
        Button signup_button = findViewById(R.id.signup);

        /*private static final String TOAST_TEXT = "This my toast message";
        toastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast toast =Toast.makeText(MainActivity.this,
                        TOAST_TEXT,Toast.LENGTH_SHORT);
                toast.show();
            }*/


       // intent = new Intent(MainActivity.this,LoginRegistrationAct.class);

        signin_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startActivity(intent);
                finish();
            }
        });

    }


}