package com.example.advancepizza;

public class Pizza {
    private String type;
    private String[] size;
    private int[] price;

    public int[] getPrice() {
        return price;
    }

    public void setPrice(int[] price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String[] getSize() {
        return size;
    }

    public void setSize(String[] size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "Pizza{" +
                "\ntype= " + type +
                "\nsize= " + size +
                "\nprice= " + price +
                +'\n'+'}'+'\n';
    }
}