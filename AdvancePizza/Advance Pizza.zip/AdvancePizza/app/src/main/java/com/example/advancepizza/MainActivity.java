package com.example.advancepizza;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;
import android.widget.ImageView;
import android.widget.Toast;
import android.util.Log;


public class MainActivity extends AppCompatActivity {

    Intent intent;

    TextView textView;

    Button getstarted_button;
    private static final String TOAST_TEXT = "Failed To Connect To Server:(";

    //pizza.setImageResource(R.drawable.pizza);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        setProgress(false);


        getstarted_button = findViewById(R.id.getstarted);
        textView = findViewById(R.id.textView3);
        ImageView pizza = (ImageView)findViewById(R.id.imageView);
        intent = new Intent(MainActivity.this,LoginRegistrationAct.class);

        }

    public void setProgress(boolean progress) {
        ProgressBar progressBar = (ProgressBar)
                findViewById(R.id.progressBar);
        if (progress) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    public void readList(List<Pizza> pizzas) {


        for (int i = 0; i < pizzas.size(); i++) {
            textView.setText(pizzas.get(i).toString());
        }

        getstarted_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConnectionAsyncTask connectionAsyncTask = new
                        ConnectionAsyncTask(MainActivity.this);
                connectionAsyncTask.execute("https://mocki.io/v1/62506512-2016-4131-8ec9-a43b6dd0db0f");
                //Log.d("TAG", PizzaJasonParser.pizzas.toString());

                if (pizzas.isEmpty()){

                    Toast toast =Toast.makeText(MainActivity.this,
                            TOAST_TEXT,Toast.LENGTH_SHORT);
                    toast.show();

                }

                else{

                    startActivity(intent);
                    finish();

                }
            }
        });

    }


}